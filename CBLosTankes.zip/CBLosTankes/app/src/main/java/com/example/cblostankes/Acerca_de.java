package com.example.cblostankes;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;


public class Acerca_de extends AppCompatActivity {

    //Fragment[] misFragmentos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_acerca_de);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
       /* misFragmentos = new Fragment[2];
        misFragmentos[0] = new MenuPelota();
        misFragmentos[1] = new JugadorBasket();
*/
        Bundle extras = getIntent().getExtras();
        String nombre = extras.getString("name");
        int edadMayor = extras.getInt("age");


        TextView name = (TextView) findViewById(R.id.TvInformacion);
        name.setText("Hola compañer@: \n" + nombre + " con " + edadMayor + " años \n" + "Bienvenid@ al equipo de los tanques." + "\n" + "Espero que estes bien.");




        // menu(extras.getInt("BOTONPULSADO"));
    }

      /*  public void menu(int queboton) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction()
                    .replace(R.id.MenuPelota, misFragmentos[queboton], null)
                    .setReorderingAllowed(true)
                    .addToBackStack("name")
                    .commit();
        }*/
}
