package com.example.cblostankes;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import androidx.fragment.app.Fragment;

public class Menu extends Fragment {

   private final int[] BOTONES_MENU = {
           R.id.MenuPelota,
           R.id.JugadorBasket
    };
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

   public Menu(){
         // Required empty public constructor
   }

    public static Menu newInstance(String param1, String param2) {
        Menu fragment = new Menu();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View mimenu = inflater.inflate(R.layout.fragment_menu, container, false);

        ImageButton botonMenu;

        for(int i=0; i < BOTONES_MENU.length; i++){
            botonMenu = mimenu.findViewById(BOTONES_MENU[i]);
            final int queBoton = i; //variable para saber que boton se ha pulsado
            botonMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //detectar en que actividad se encuentra el boton pulsado
                    Activity estaActividad = getActivity();
                    if (estaActividad instanceof MainActivity) {
                        if (queBoton == 0) {
                            ((MainActivity) estaActividad).menu(queBoton);
                        } else {
                            Intent intent = new Intent(estaActividad, RegistroActivity.class);
                            startActivity(intent);
                        }
                    }
                }
            });
        }

        return mimenu;
    }
}