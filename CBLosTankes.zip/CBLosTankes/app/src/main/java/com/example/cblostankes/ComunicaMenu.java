package com.example.cblostankes;

public interface ComunicaMenu{
    public void menu(int queboton);


}
