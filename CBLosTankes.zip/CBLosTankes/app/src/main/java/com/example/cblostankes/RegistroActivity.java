package com.example.cblostankes;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroActivity extends AppCompatActivity {

    private EditText edtNombre, edtApellido1, edtApellido2, edAltura;
    private Spinner spinnerGenero;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        edtNombre = findViewById(R.id.edtnombre);
        edtApellido1 = findViewById(R.id.edtApellido1);
        edtApellido2 = findViewById(R.id.edtApellido2);
        edAltura = findViewById(R.id.edAltura);
        spinnerGenero = findViewById(R.id.idSpinner);
        Button btInfo = findViewById(R.id.btInfo);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.genero_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGenero.setAdapter(adapter);

        btInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarInfo();
            }
        });
    }

    private void mostrarInfo() {
        String nombre = edtNombre.getText().toString();
        String apellido1 = edtApellido1.getText().toString();
        String apellido2 = edtApellido2.getText().toString();
        String altura = edAltura.getText().toString();
        double alturaCm = Double.parseDouble(altura)/100;
        String genero = spinnerGenero.getSelectedItem().toString();

        String mensaje;
        if (genero.equals("Femenino")) {
            mensaje = "La jugadora " + nombre + " " + apellido1 + " " + apellido2 + ", Tiene una altura de " + alturaCm + " metros";
        } else {
            mensaje = "El jugador " + nombre + " " + apellido1 + " " + apellido2 + ", Tiene una altura de " + alturaCm + " metros";
        }

        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
    }
}